const starterProducts=[
 {id:1,name:"Toor Dal 1kg",price:145,cost:118,stock:4,reorder:8},
 {id:2,name:"Rice 5kg",price:320,cost:275,stock:18,reorder:6},
 {id:3,name:"Sunflower Oil 1L",price:145,cost:126,stock:5,reorder:8},
 {id:4,name:"Sugar 1kg",price:48,cost:41,stock:22,reorder:8},
 {id:5,name:"Tea 250g",price:125,cost:98,stock:12,reorder:5},
 {id:6,name:"Bath Soap",price:38,cost:29,stock:3,reorder:10}
];
let products=JSON.parse(localStorage.getItem("ss_products")||"null")||starterProducts;
let sales=JSON.parse(localStorage.getItem("ss_sales")||"[]");
const money=n=>"₹"+Number(n||0).toLocaleString("en-IN",{maximumFractionDigits:2});
const save=()=>{localStorage.setItem("ss_products",JSON.stringify(products));localStorage.setItem("ss_sales",JSON.stringify(sales));};
const today=()=>new Date().toDateString();
function render(){
 const todays=sales.filter(s=>new Date(s.time).toDateString()===today());
 const revenue=todays.reduce((a,s)=>a+s.amount,0),profit=todays.reduce((a,s)=>a+s.profit,0);
 document.getElementById("todaySales").textContent=money(revenue);
 document.getElementById("grossProfit").textContent=money(profit);
 document.getElementById("productCount").textContent=products.length;
 const low=products.filter(p=>p.stock<=p.reorder);
 document.getElementById("lowCount").textContent=low.length;
 document.getElementById("alerts").innerHTML=low.length?low.map(p=>`<div class="alert ${p.stock===0?'red':''}"><strong>${esc(p.name)}</strong><br>${p.stock===0?'Out of stock':p.stock+' units left'} · reorder level ${p.reorder}</div>`).join(""):'<div class="insight">✓ No low-stock alerts right now.</div>';
 document.getElementById("dashboardInsight").textContent=low.length?`Check ${low.map(p=>p.name).join(", ")}. Consider reviewing supplier lead times before reordering.`:"Your current stock is above its reorder levels. Keep recording sales to build a useful sales history.";
 const totals={};sales.forEach(s=>totals[s.name]=(totals[s.name]||0)+s.amount);
 const best=Object.entries(totals).sort((a,b)=>b[1]-a[1]).slice(0,5),max=Math.max(1,...best.map(x=>x[1]));
 document.getElementById("salesBars").innerHTML=best.length?best.map(([n,v])=>`<div class="barrow"><span>${esc(n)}</span><div class="track"><div class="fill" style="width:${v/max*100}%"></div></div><strong>${money(v)}</strong></div>`).join(""):'<div class="empty">No sales yet. Record a sale to see product performance.</div>';
 document.getElementById("inventoryRows").innerHTML=products.length?products.map(p=>`<tr><td><strong>${esc(p.name)}</strong></td><td>${money(p.price)}</td><td>${money(p.cost)}</td><td>${p.stock}</td><td><span class="status ${p.stock<=p.reorder?'low':'ok'}">${p.stock<=p.reorder?(p.stock===0?'Out of stock':'Low stock'):'In stock'}</span></td><td><button class="danger" onclick="removeProduct(${p.id})">Remove</button></td></tr>`).join(""):'<tr><td colspan="6" class="empty">No products. Add your first product.</td></tr>';
 document.getElementById("saleProduct").innerHTML=products.map(p=>`<option value="${p.id}">${esc(p.name)} · ${money(p.price)} · ${p.stock} in stock</option>`).join("");
 document.getElementById("salesRows").innerHTML=sales.slice().reverse().slice(0,20).map(s=>`<tr><td>${new Date(s.time).toLocaleString("en-IN")}</td><td>${esc(s.name)}</td><td>${s.qty}</td><td>${money(s.amount)}</td><td>${esc(s.payment)}</td></tr>`).join("")||'<tr><td colspan="5" class="empty">No sales recorded yet.</td></tr>';
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function removeProduct(id){if(confirm("Remove this product from inventory? Past sales will remain.")){products=products.filter(p=>p.id!==id);save();render();}}
window.removeProduct=removeProduct;
document.querySelectorAll(".nav button").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".nav button").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.querySelectorAll(".page").forEach(x=>x.classList.add("hidden"));document.getElementById(b.dataset.page).classList.remove("hidden");const titles={dashboard:["Good day, shop owner 👋","Here is what's happening in your kirana store."],inventory:["Inventory","Manage products, prices and stock levels."],sales:["Record a sale","Keep your daily sales and stock up to date."],advisor:["AI Business Advisor","Turn your shop data into practical next steps."]};document.getElementById("pageTitle").textContent=titles[b.dataset.page][0];document.getElementById("pageSub").textContent=titles[b.dataset.page][1];}));
document.getElementById("showAdd").onclick=()=>document.getElementById("addPanel").classList.remove("hidden");
document.getElementById("cancelAdd").onclick=()=>document.getElementById("addPanel").classList.add("hidden");
document.getElementById("productForm").onsubmit=e=>{e.preventDefault();const name=document.getElementById("pName").value.trim(),price=+document.getElementById("pPrice").value,cost=+document.getElementById("pCost").value,stock=+document.getElementById("pStock").value,reorder=+document.getElementById("pReorder").value;if(!name||price<=0||cost<0||stock<0||reorder<0)return;products.push({id:Date.now(),name,price,cost,stock,reorder});save();e.target.reset();document.getElementById("pReorder").value=5;document.getElementById("addPanel").classList.add("hidden");render();};
document.getElementById("saleForm").onsubmit=e=>{e.preventDefault();const id=+document.getElementById("saleProduct").value,p=products.find(x=>x.id===id),qty=+document.getElementById("saleQty").value;if(!p||qty<1)return;if(qty>p.stock){document.getElementById("saleFeedback").textContent=`Not enough stock. Only ${p.stock} units of ${p.name} are available.`;return;}const amount=p.price*qty,profit=(p.price-p.cost)*qty;p.stock-=qty;sales.push({time:new Date().toISOString(),id:p.id,name:p.name,qty,amount,profit,payment:document.getElementById("salePayment").value});save();render();document.getElementById("saleFeedback").textContent=`Sale saved: ${qty} × ${p.name} = ${money(amount)}. Estimated gross profit: ${money(profit)}.`;document.getElementById("saleQty").value=1;};
function advise(q){const low=products.filter(p=>p.stock<=p.reorder),sorted=products.slice().sort((a,b)=>b.stock-a.stock),sold={};sales.forEach(s=>sold[s.id]=(sold[s.id]||0)+s.qty);const noSales=products.filter(p=>!sold[p.id]);let answer="";
if(/reorder|stock|low/i.test(q)){answer=low.length?`These products are at or below their reorder level: ${low.map(p=>`${p.name} (${p.stock} left; reorder level ${p.reorder})`).join("; ")}. Check current demand and supplier delivery time, then decide the purchase quantity.`:"No products are currently below their reorder level. Keep recording sales so reorder suggestions become more useful.";}
else if(/slow|not selling|unsold/i.test(q)){answer=noSales.length?`No sales have been recorded for: ${noSales.map(p=>p.name).join(", ")}. This does not prove they are slow-moving; record sales over several weeks before deciding. Consider checking expiry dates and shelf placement.`:"Sales have been recorded for all listed products. Compare quantities sold over a consistent period to identify slow movers.";}
else if(/profit|margin|improve/i.test(q)){const margins=products.map(p=>({name:p.name,margin:p.price-p.cost})).sort((a,b)=>b.margin-a.margin);answer=`Your highest gross-profit amount per unit is ${margins[0]?.name||"not available"} (${money(margins[0]?.margin||0)} per unit). Review supplier prices, wastage, discounts and product mix. Gross profit here excludes rent, wages and other overheads.`;}
else if(/sales|revenue|how are/i.test(q)){const total=sales.reduce((a,s)=>a+s.amount,0),qty=sales.reduce((a,s)=>a+s.qty,0);answer=`You have recorded ${money(total)} in sales across ${sales.length} transactions (${qty} units). This is demo history only; compare the same weekdays across multiple weeks for a fair trend.`;}
else{answer=`I can help with stock, sales and profit. You currently have ${products.length} products, ${low.length} low-stock items and ${sales.length} recorded sales. Try asking: “What should I reorder?” or “How can I improve profit?”`;}
document.getElementById("answer").textContent=answer;}
document.getElementById("askBtn").onclick=()=>{const q=document.getElementById("question").value.trim();if(q)advise(q);};
document.getElementById("question").addEventListener("keydown",e=>{if(e.key==="Enter")document.getElementById("askBtn").click();});
document.querySelectorAll("[data-question]").forEach(b=>b.onclick=()=>{document.getElementById("question").value=b.dataset.question;advise(b.dataset.question);});
render();
